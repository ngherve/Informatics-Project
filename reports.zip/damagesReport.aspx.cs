﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Services;
using System.Web.Services;
using TYPPrototype.ProductService;

namespace TYPPrototype
{
    public partial class damagesReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetChartData();
        }
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static object[] GetChartData()
        {
            ProductServiceClient prodService;
            Damaged[] products;
            prodService = new ProductServiceClient();

            products = prodService.GetDamagedProducts();
            List<Damaged> data = new List<Damaged>();
            data = products.ToList();

            var chartData = new object[products.Count() + 1];
            chartData[0] = new object[]
            {
                    "Damaged ID and Product ID ",
                    "Quantity "
            };
            int j = 0;
            foreach (var i in data)
            {
                j++;
                chartData[j] = new object[] { i.D_ID.ToString() + " : " + i.P_ID, i.Quantity};
            }

            return chartData;
        }
    }
}