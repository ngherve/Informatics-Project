﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Services;
using System.Web.Services;
using TYPPrototype.UserService;


namespace TYPPrototype
{
    public partial class EmployeeReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetChartData();
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static object[] GetChartData()
        {
            UserServiceClient userService;
            Task[] task;
            userService = new UserServiceClient();

            task = userService.GetTasks();
            List<Task> data = new List<Task>();
            data = task.ToList();

            var chartData = new object[task.Count() + 1];
            chartData[0] = new object[]
            {
                    
                    "User ID and Task Type",
                    "Task ID ",
                   

            };
            int j = 0;
            foreach (var i in data)
            {
                j++;
                chartData[j] = new object[] { i.UserID.ToString() +" : " +  i.T_Type,i.Task_ID};
                
            }

            return chartData;
        }
    }
}
